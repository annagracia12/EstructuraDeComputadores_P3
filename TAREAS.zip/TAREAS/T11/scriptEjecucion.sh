#!/bin/bash


#variable para nombre del archivo
x=1

while [ $x -le 7 ]
do

    echo "ejecutando cacti $x"
    cacti -infile 64_$x.cfg > resultado_$x.txt
    
    let x=x+1
done

echo "fin"