#!/bin/bash


#variable para nombre del archivo
x=16

while [ $x -le 8192 ]
do

    echo "ejecutando cacti con cache de $x KB"
    cacti -infile $x.cfg > resultado_$x.txt
    
    let x=x*2
done

echo "fin"