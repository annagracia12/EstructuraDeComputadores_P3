#!/bin/bash

#----------------------------------
#parte de calculos
#----------------------------------
#numLineas = numSets * asoc
#tamañoTotal = numSets * asoc * blocSize
#numSets = tamañoTotal / (asoc(=1) * blocSize) = tamañoTotal / blocSize

#numSets1 = 16*1024b(=16Kb) / 8 = 2048
#numSets2 = 16*1024b(=16Kb) / 16 = 1024
#numSets3 = 16*1024b(=16Kb) / 32 = 512
#numSets4 = 16*1024b(=16Kb) / 64 = 256

#a partir de ahora las chaches vinen definidas por:
#-cache:dl1 datosL1:numSets:16:1:l

#----------------------------------
#parte a ejecutar
#----------------------------------

#hacer bucle para agilizar la ejecucion
x=256
b=64
while [ $x -le 2048 ]
do 
    #parte applu
    cd /lib/specs2000/applu/data/ref

    echo "ejecutando parte de applu cache bsize=$b nsets=$x..."
    #en el directorio, ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/applu/applu_$x.txt ../../exe/applu.exe < applu.in > /home/milax/EC/practica3/TAREAS/T7/applu/applu_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/applu/applu_$x.err

    #prueba con crafty
    cd /lib/specs2000/crafty/data/ref

    echo "ejecutando parte de crafty cache bsize=$b nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/crafty/crafty_$x.txt ../../exe/crafty.exe < crafty.in > /home/milax/EC/practica3/TAREAS/T7/crafty/crafty_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/crafty/crafty_$x.err

    #prueba con mesa
    cd /lib/specs2000/mesa/data/ref

    echo "ejecutando parte de mesa cache bsize=$b nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/mesa/mesa_$x.txt ../../exe/mesa.exe -frames 1000 -meshfile mesa.in -ppmfile mesa.ppm

    #prueba con vortex
    cd /lib/specs2000/vortex/data/ref

    echo "ejecutando parte de vortex1 cache bsize=$b nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/vortex/vortex1_$x.txt ../../exe/vortex.exe lendian1.raw > /home/milax/EC/practica3/TAREAS/T7/vortex/vortex1_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/vortex/vortex1_$x.err

    echo "ejecutando parte de vortex2 cache bsize=$b nsets=$x..."
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/vortex/vortex2_$x.txt ../../exe/vortex.exe lendian2.raw > /home/milax/EC/practica3/TAREAS/T7/vortex/vortex2_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/vortex/vortex2_$x.err

    echo "ejecutando parte de vortex3 cache bsize=$b nsets=$x..."
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/vortex/vortex3_$x.txt ../../exe/vortex.exe lendian3.raw > /home/milax/EC/practica3/TAREAS/T7/vortex/vortex3_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/vortex/vortex3_$x.err

    #prueba con vpr
    cd /lib/specs2000/vpr/data/ref

    echo "ejecutando parte de vpr cache bsize=$b nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/vpr/vpr1_$x.txt ../../exe/vpr.exe net.in arch.in place.out dum.out -nodisp -place_only -init_t 5 -exit_t 0.005 -alpha_t 0.9412 -inner_num 2 > /home/milax/EC/practica3/TAREAS/T7/vpr/place_log_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/vpr/place_log_$x.err
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:$b:1:l -redir:sim /home/milax/EC/practica3/TAREAS/T7/vpr/vpr2_$x.txt ../../exe/vpr.exe net.in arch.in place.in route.out -nodisp -route_only -route_chan_width 15 -pres_fac_mult 2 -acc_fac 1 -first_iter_pres_fac 4 -initial_pres_fac 8 > /home/milax/EC/practica3/TAREAS/T7/vpr/route_log_$x.out 2> /home/milax/EC/practica3/TAREAS/T7/vpr/route_log_$x.err



    #cambiar valor de la variable para actualizar valor de la cache
    let x=x*2
	let b=b/2
done
