#!/bin/bash

#----------------------------------
#parte de calculos
#----------------------------------
#numLineas = numSets * asoc
#tamañoTotal = numSets * asoc * blocSize
#numSets = tamañoTotal / (asoc * blocSize)

#dl1
#tamañoTotal = 32kb/2 = 16Kb = 16384b
#numSets = 16384b/ (64b * 2) = 128

#il1
#tamañoTotal = 48kb/2 = 24Kb = 24576b
#numSets = 24576b/ (64b * 3) = 128
#como cacti ni simplescalar no aceptan asociatividad = 3, asumimos asociatividad = 4.




#a partir de ahora las chaches vinen definidas por:
#-cache:dl1 datosL1:numSets:16:1:l

#----------------------------------
#parte a ejecutar
#----------------------------------

echo "+++++++++++++++++++++++++++++++++++++++"

echo "CACTI"
echo "Ejecutando con cache dl1"
cacti -infile dl1.cfg > ./resultado_dl1.txt

echo "Ejecutando con cache il1"
cacti -infile il1.cfg > ./resultado_il1.txt


#parte applu
cd /lib/specs2000/applu/data/ref

echo "+++++++++++++++++++++++++++++++++++++++"
echo "APPLU"
#en el directorio, ejecutar comando
echo "Ejecutando con cache dl1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/applu/tarea13_dl1.txt ../../exe/applu.exe < applu.in > /home/milax/EC/practica3/TAREAS/T13/applu/tarea13_dl1.out 2> /home/milax/EC/practica3/TAREAS/T13/applu/tarea13_dl1.err
echo "Ejecutando con cache il1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:il1 il1:128:64:4:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/applu/tarea13_il1.txt ../../exe/applu.exe < applu.in > /home/milax/EC/practica3/TAREAS/T13/applu/tarea13_il1.out 2> /home/milax/EC/practica3/TAREAS/T13/applu/tarea13_il1.err
echo "+++++++++++++++++++++++++++++++++++++++"

#prueba con crafty
cd /lib/specs2000/crafty/data/ref

echo "CRAFTY"
#ejecutar comando
echo "Ejecutando con cache dl1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/crafty/tarea13_dl1.txt ../../exe/crafty.exe < crafty.in > /home/milax/EC/practica3/TAREAS/T13/crafty/tarea13_dl1.out 2> /home/milax/EC/practica3/TAREAS/T13/crafty/tarea13_dl1.err
echo "Ejecutando con cache il1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:il1 il1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/crafty/tarea13_il1.txt ../../exe/crafty.exe < crafty.in > /home/milax/EC/practica3/TAREAS/T13/crafty/tarea13_il1.out 2> /home/milax/EC/practica3/TAREAS/T13/crafty/tarea13_il1.err
echo "+++++++++++++++++++++++++++++++++++++++"

#prueba con mesa
cd /lib/specs2000/mesa/data/ref

echo "MESA"
#ejecutar comando
echo "Ejecutando con cache dl1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/mesa/tarea13_dl1.txt ../../exe/mesa.exe -frames 1000 -meshfile mesa.in -ppmfile mesa.ppm
echo "Ejecutando con cache il1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:il1 il1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/mesa/tarea13_il1.txt ../../exe/mesa.exe -frames 1000 -meshfile mesa.in -ppmfile mesa.ppm
echo "+++++++++++++++++++++++++++++++++++++++"


#prueba con vortex
cd /lib/specs2000/vortex/data/ref

echo "VORTEX"
#ejecutar comando
echo "Ejecutando con cache dl1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/vortex/tarea13_dl1.txt ../../exe/vortex.exe lendian1.raw > /home/milax/EC/practica3/TAREAS/T13/vortex/vortex_dl1.out 2> /home/milax/EC/practica3/TAREAS/T13/vortex/vortex_dl1.err
echo "Ejecutando con cache il1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:il1 il1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/vortex/tarea13_il1.txt ../../exe/vortex.exe lendian1.raw > /home/milax/EC/practica3/TAREAS/T13/vortex/vortex_il1.out 2> /home/milax/EC/practica3/TAREAS/T13//vortex_il1.err
echo "+++++++++++++++++++++++++++++++++++++++"

#prueba con vpr
cd /lib/specs2000/vpr/data/ref

echo "VPR"
#ejecutar comando
echo "Ejecutando con cache dl1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/vpr/tarea13_dl1.txt ../../exe/vpr.exe net.in arch.in place.out dum.out -nodisp -place_only -init_t 5 -exit_t 0.005 -alpha_t 0.9412 -inner_num 2 > /home/milax/EC/practica3/TAREAS/T13/vpr/place_log_dl1.out 2> /home/milax/EC/practica3/TAREAS/T13/vpr/place_log_dl1.err
echo "Ejecutando con cache il1"
sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:il1 il1:128:64:2:l -redir:sim /home/milax/EC/practica3/TAREAS/T14/vpr/tarea13_il1.txt ../../exe/vpr.exe net.in arch.in place.out dum.out -nodisp -place_only -init_t 5 -exit_t 0.005 -alpha_t 0.9412 -inner_num 2 > /home/milax/EC/practica3/TAREAS/T13/vpr/place_log_il1.out 2> /home/milax/EC/practica3/TAREAS/T13/vpr/place_log_il1.err


echo "+++++++++++++++++++++++++++++++++++++++"


echo "fin"
