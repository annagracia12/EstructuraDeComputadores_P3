#!/bin/bash

#----------------------------------
#parte de calculos
#----------------------------------
#numLineas = numSets * asoc
#tamañoTotal = numSets * asoc * blocSize
#numSets = tamañoTotal / (asoc(=1) * blocSize) = tamañoTotal / blocSize

#numSets1 = 1024b(=1Kb) / 16b = 64
#numSets2 = 2048b(=2Kb) / 16b = 128
#numSets4 = 4096b(=4Kb) / 16b = 256
#numSets8 = 8192b(=8Kb) / 16b = 512
#numSets16 = 16384b(=16Kb) / 16b = 1024
#numSets32 = 32768b(=32Kb) / 16b = 2048
#numSets64 = 65536b(=64Kb) / 16b = 4096

#a partir de ahora las chaches vinen definidas por:
#-cache:dl1 datosL1:numSets:16:1:l

#----------------------------------
#parte a ejecutar
#----------------------------------

#hacer bucle para agilizar la ejecucion
x=16
a=64

while [ $x -le 1024 ]
do 
    #parte applu
    cd /lib/specs2000/applu/data/ref

    echo "ejecutando parte de applu cache asoc=$a nsets=$x..."
    #en el directorio, ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/applu/applu_$x.txt ../../exe/applu.exe < applu.in > /home/milax/EC/practica3/TAREAS/T5/applu/applu_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/applu/applu_$x.err

    #prueba con crafty
    cd /lib/specs2000/crafty/data/ref

    echo "ejecutando parte de crafty cache asoc=$a nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/crafty/crafty_$x.txt ../../exe/crafty.exe < crafty.in > /home/milax/EC/practica3/TAREAS/T5/crafty/crafty_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/crafty/crafty_$x.err

    #prueba con mesa
    cd /lib/specs2000/mesa/data/ref

    echo "ejecutando parte de mesa cache asoc=$a nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/mesa/mesa_$x.txt ../../exe/mesa.exe -frames 1000 -meshfile mesa.in -ppmfile mesa.ppm

    #prueba con vortex
    cd /lib/specs2000/vortex/data/ref

    echo "ejecutando parte de vortex1 cache asoc=$a nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/vortex/vortex1_$x.txt ../../exe/vortex.exe lendian1.raw > /home/milax/EC/practica3/TAREAS/T5/vortex/vortex1_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/vortex/vortex1_$x.err

    echo "ejecutando parte de vortex2 cache asoc=$a nsets=$x..."
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/vortex/vortex2_$x.txt ../../exe/vortex.exe lendian2.raw > /home/milax/EC/practica3/TAREAS/T5/vortex/vortex2_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/vortex/vortex2_$x.err

    echo "ejecutando parte de vortex3 cache asoc=$a nsets=$x..."
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/vortex/vortex3_$x.txt ../../exe/vortex.exe lendian3.raw > /home/milax/EC/practica3/TAREAS/T5/vortex/vortex3_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/vortex/vortex3_$x.err

    #prueba con vpr
    cd /lib/specs2000/vpr/data/ref

    echo "ejecutando parte de vpr cache asoc=$a nsets=$x..."
    #ejecutar comando
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/vpr/vpr1_$x.txt ../../exe/vpr.exe net.in arch.in place.out dum.out -nodisp -place_only -init_t 5 -exit_t 0.005 -alpha_t 0.9412 -inner_num 2 > /home/milax/EC/practica3/TAREAS/T5/vpr/place_log_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/vpr/place_log_$x.err
    sim-outorder -fastfwd 100000000 -max:inst 100000000 -cache:dl1 dl1:$x:16:$a:l -redir:sim /home/milax/EC/practica3/TAREAS/T5/vpr/vpr2_$x.txt ../../exe/vpr.exe net.in arch.in place.in route.out -nodisp -route_only -route_chan_width 15 -pres_fac_mult 2 -acc_fac 1 -first_iter_pres_fac 4 -initial_pres_fac 8 > /home/milax/EC/practica3/TAREAS/T5/vpr/route_log_$x.out 2> /home/milax/EC/practica3/TAREAS/T5/vpr/route_log_$x.err



    #cambiar valor de la variable para actualizar valor de la cache
    let x=x*2
	let a=a/2
done
